# Import Module
# import all components
# from the tkinter library
from tkinter import *
from tkinter.font import Font 

# import filedialog module
from tkinter import filedialog

#module to use jpg pictures
from PIL import Image,ImageTk
from matplotlib import pyplot as plt 


import cv2
import matplotlib.pyplot as plt
import numpy as np

# create root window
root = Tk()
 
# root window title and dimension
root.title("Proiect Prelucrarea Numerica a Imaginilor")
# Set geometry(widthxheight)
root.geometry('800x500')

#define our font
bigFont = Font(
    family = "Segoe Script",
    size = 35,
    weight = "bold",
    underline = 0)

# Add image file 
img= Image.open("images2/solid.jpg")
bg = ImageTk.PhotoImage(img)

img2= Image.open("images2/aba2.png")
bg2 = ImageTk.PhotoImage(img2)

#create canvas
my_canvas = Canvas(root, width=800, height=500)
my_canvas.pack(fill="both", expand=True)

#set image in canvas
my_canvas.create_image(0,0,image=bg,anchor="nw")
#my_canvas.create_image(300,400,image=bg1,anchor="nw")
my_canvas.create_image(800,100,image=bg2,anchor="nw")

#add label
my_canvas.create_text(400,250, text = "Iris image segmentation", font=bigFont)
my_canvas.create_text(400,300, text = "Inner Iris Boundary Detection", font=bigFont)

#create command to close window
def Close(): 
    root.destroy() 
    
# Function for opening the 
# file explorer window
def browseFiles():
    global my_image
    filename = filedialog.askopenfilename(initialdir = "\Iris_Inner_BoundaryDetection-PROJECT\images2",
                                          title = "Select a File",
                                          filetypes = (("Text files",
                                                        "*.txt*"),
                                                       ("all files",
                                                        "*.*")))

    org = cv2.imread(filename)

    #show original image
    plt.figure()
    plt.imshow(org)
    plt.suptitle('Imaginea originala')
    plt.show()
    
    # Convert image to grayscale
    gray_image = cv2.cvtColor(org, cv2.COLOR_BGR2GRAY)

    #STEP 1 - Apply a threshold to create a binary image
    #Pixels with intensity values less than 10 will be set to 0 (black)
    #Pixels with intensity values greater than or equal to 10 will be set to 255 (white).
    ret, bw_img = cv2.threshold(gray_image,10, 255, cv2.THRESH_BINARY) 
    
    #show binary image
    plt.figure()
    plt.imshow(bw_img,cmap='gray')
    plt.suptitle('Imaginea binara')
    plt.show()
    
    # Invert the image (make black pixels white and vice versa) to make the pupil white
    inverted_image = cv2.bitwise_not(bw_img)

    #STEP 2 - Perform morphological closing to fill white holes
    #useful in closing small holes inside the foreground objects, or small black points on the object.
    kernel = np.ones((9, 9), np.uint8) #structuring element
    closed_image = cv2.morphologyEx(inverted_image, cv2.MORPH_CLOSE, kernel)
    
    # Invert the result back to the original format to make the pupil fully black
    filled_iris_image = cv2.bitwise_not(closed_image)
    
    #show filled iris image
    plt.figure()
    plt.imshow(filled_iris_image, cmap='gray')
    plt.suptitle('Imaginea prelucrata')
    plt.show()
    
    #STEP 3 - Sobel filters
    # Apply the Sobel filter for vertical edge detection
    
    #cv2.CV_64F = the destination image will have the same depth as the source
    #ksize parameter influences the level of detail captured in the detected edges.
    sobel_vertical = cv2.Sobel(filled_iris_image, cv2.CV_64F, 0, 1, ksize=1)
    
    
    plt.figure()
    plt.imshow(sobel_vertical, cmap='gray')
    plt.suptitle('Sobel vertical')
    plt.show()
    
    
    # Apply the Sobel filter for horizontal edge detection
    sobel_horizontal = cv2.Sobel(filled_iris_image, cv2.CV_64F, 1, 0, ksize=1)
    
    plt.figure()
    plt.imshow(sobel_horizontal, cmap='gray')
    plt.suptitle('Sobel orizontal')
    plt.show()
    
    
    #STEP 4 - Combine the vertical and horizontal edge images
    combined_edges = cv2.addWeighted(cv2.convertScaleAbs(sobel_vertical), 0.5, cv2.convertScaleAbs(sobel_horizontal), 0.5, 0)
    
    #show image after sobel filters
    plt.figure()
    plt.imshow(combined_edges,cmap='gray')
    plt.suptitle('Sobel filter')
    plt.show()
    
    #STEP 5 - Threshold the combined_edges image to get a binary image with strong edges
    threshold_value = 12  
    _, strong_edges = cv2.threshold(combined_edges, threshold_value, 255, cv2.THRESH_BINARY)
    
    plt.figure()
    plt.imshow(strong_edges,cmap='gray')
    plt.suptitle('Strong edges')
    plt.show()
    
   
    #STEP 6 - Apply Hough Circle Transform to detect circles (pupil boundary)
    min_radius = 10
    max_radius = 80
    #A = vector that stores sets of 3 values (xc,yc,r)
    #param 1 =  this is a parameter used for edge detection in the Hough transformation
    #param2 = it indicates the minimum number of votes required for a circle to be detected
    #dp=1 => the accumulator has the same resolution as the input image
    A = cv2.HoughCircles(strong_edges, cv2.HOUGH_GRADIENT, dp=1, minDist=20,
                               param1=100, param2=20, minRadius=min_radius, maxRadius=max_radius)
    
    #Overlay the detected circles on the original eye image
    result_image = org.copy()
    
    if A is not None:
        A = np.uint16(np.around(A))
        for circle in A[0, :]:
            center = (circle[0], circle[1])
            radius = circle[2]
            # Draw the circle detected as the pupil boundary on the result image
            cv2.circle(result_image, center, radius, (237, 231, 50), 3)
    
    # Display the result
    cv2.imshow('Pupil Boundary Detection', result_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
        
    
#add button
button3 = Button(root,text="Exit", command=Close)
button4 = Button(root,text="Open Image",command=browseFiles)

#add buttons to canvas
button3_window = my_canvas.create_window(50,10,anchor="nw",window=button3)
button4_window = my_canvas.create_window(150,10,anchor="nw",window=button4)

# Execute Tkinter
root.mainloop()